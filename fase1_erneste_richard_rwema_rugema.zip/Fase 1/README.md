Om het spel te kunnen spellen moet het bestand "Fire-Ant.rkt" (gesitueert in De FireAnt map) geopend worden in DrRacket en dan gerund worden.
